## Dataset from:

https://www.kaggle.com/mrisdal/fake-news